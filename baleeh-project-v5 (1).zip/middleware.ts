import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

const AREAS = ['owner', 'lawyer'] as const

export async function middleware(req: NextRequest) {
  const area = AREAS.find((a) => req.nextUrl.pathname.startsWith('/' + a))
  if (!area) return NextResponse.next()

  let res = NextResponse.next({ request: req })
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (list) => {
        res = NextResponse.next({ request: req })
        list.forEach(({ name, value, options }) => res.cookies.set(name, value, options))
      },
    },
  })
  const { data: { user } } = await sb.auth.getUser() // تحقق من السيرفر وليس من الكوكي فقط
  if (!user) return NextResponse.redirect(new URL('/login', req.url))

  const { data: p } = await sb.from('profiles').select('role,is_active').eq('id', user.id).single()
  if (!p?.is_active || p.role !== area) return NextResponse.redirect(new URL('/login', req.url))
  return res
}
export const config = { matcher: ['/owner/:path*', '/lawyer/:path*'] }
