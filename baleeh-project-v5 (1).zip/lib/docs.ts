import { requireRole } from './role'
import { adminClient } from './supabase'
import { headers } from 'next/headers'

// رفع مستند لقضية: يتحقق من صلاحية المستخدم على القضية (RLS) ثم يخزّن في bucket خاص
export async function saveDocument(caseId: string, file: File, visible = false) {
  const sb = (await import('./supabase')).serverClient
  const client = await sb()
  const { data: { user } } = await client.auth.getUser()
  if (!user) throw new Error('unauthorized')
  const { data: c } = await client.from('cases').select('id').eq('id', caseId).maybeSingle() // RLS
  if (!c) throw new Error('forbidden')
  const { data: prof } = await client.from('profiles').select('role').eq('id', user.id).single()
  if (prof?.role === 'client') throw new Error('forbidden')
  if (file.size > 25 * 1024 * 1024) throw new Error('الملف أكبر من 25MB')
  const ok = ['application/pdf', 'image/jpeg', 'image/png']
  if (!ok.includes(file.type)) throw new Error('نوع الملف غير مسموح')
  const admin = adminClient()
  const path = `${caseId}/${crypto.randomUUID()}`
  const { error } = await admin.storage.from('case-docs').upload(path, file, { contentType: file.type })
  if (error) throw new Error(error.message)
  const { data: d } = await admin.from('documents').insert({ case_id: caseId, name: file.name, path, mime: file.type, size: file.size, client_visible: visible, uploaded_by: user.id }).select('id').single()
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'DOCUMENT_UPLOADED', entity: 'document', entity_id: d?.id, ip: (await headers()).get('x-forwarded-for')?.split(',')[0] ?? null })
  return d?.id
}
