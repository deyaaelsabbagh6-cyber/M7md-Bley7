'use server'
import { revalidatePath } from 'next/cache'
import { headers } from 'next/headers'
import { requireRole } from '@/lib/role'

export async function checkIn() {
  const { admin, user } = await requireRole('lawyer')
  const { data: open } = await admin.from('attendance').select('id').eq('lawyer_id', user.id).is('check_out', null).maybeSingle()
  if (open) return
  const ua = (await headers()).get('user-agent')
  await admin.from('attendance').insert({ lawyer_id: user.id, user_agent: ua }) // الوقت من السيرفر
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'CHECK_IN' })
  revalidatePath('/lawyer')
}
export async function checkOut() {
  const { admin, user } = await requireRole('lawyer')
  await admin.from('attendance').update({ check_out: new Date().toISOString() }).eq('lawyer_id', user.id).is('check_out', null)
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'CHECK_OUT' })
  revalidatePath('/lawyer')
}
