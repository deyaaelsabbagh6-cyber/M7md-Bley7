import Link from 'next/link'
import { requireRole } from '@/lib/role'
export default async function L({ children }: { children: React.ReactNode }) {
  await requireRole('lawyer')
  return (
    <div dir="rtl" style={{ minHeight: '100vh', background: '#070605', color: '#f4ecd8', paddingBottom: 70 }}>
      <main style={{ padding: 18 }}>{children}</main>
      <nav style={{ position: 'fixed', bottom: 0, inset: 'auto 0 0 0', display: 'flex', justifyContent: 'space-around', padding: 12, background: '#000e', borderTop: '1px solid #d4af37' }}>
        <Link href="/lawyer" style={{ color: '#f3d98b' }}>🕘 الحضور</Link>
        <Link href="/lawyer/cases" style={{ color: '#f3d98b' }}>📁 القضايا</Link>
      </nav>
    </div>
  )
}
