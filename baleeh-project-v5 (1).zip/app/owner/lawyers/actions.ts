'use server'
import { revalidatePath } from 'next/cache'
import { requireOwner } from '@/lib/owner'

export async function createLawyer(f: FormData) {
  const { admin, user } = await requireOwner()
  const username = String(f.get('username')).trim().toLowerCase()
  if (!/^[a-z0-9._-]{3,30}$/.test(username)) throw new Error('اسم المستخدم: حروف إنجليزية وأرقام 3-30')
  const email = `${username}@baleeh.local`, password = String(f.get('password')), name = String(f.get('name'))
  if (password.length < 10) throw new Error('كلمة المرور أقل من 10 أحرف')
  const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: name } })
  if (error || !data.user) throw new Error(error?.message ?? 'فشل الإنشاء')
  const id = data.user.id
  await admin.from('profiles').update({ role: 'lawyer', username, full_name: name, phone: String(f.get('phone') || '') }).eq('id', id)
  await admin.from('lawyers').insert({ id, employee_id: String(f.get('emp') || '') || null })
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'USER_CREATED', entity: 'lawyer', entity_id: id }) // بدون كلمة المرور
  revalidatePath('/owner/lawyers')
}

export async function toggleLawyer(id: string, active: boolean) {
  const { admin, user } = await requireOwner()
  await admin.from('profiles').update({ is_active: active }).eq('id', id)
  await admin.auth.admin.updateUserById(id, { ban_duration: active ? 'none' : '876000h' })
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'PERMISSION_CHANGED', entity: 'lawyer', entity_id: id, meta: { is_active: active } })
  revalidatePath('/owner/lawyers')
}

export async function resetLawyerPassword(id: string, f: FormData) {
  const { admin, user } = await requireOwner()
  const pw = String(f.get('pw'))
  if (pw.length < 10) throw new Error('كلمة المرور أقل من 10 أحرف')
  await admin.auth.admin.updateUserById(id, { password: pw })
  await admin.from('audit_logs').insert({ actor_id: user.id, action: 'PASSWORD_CHANGE', entity: 'lawyer', entity_id: id })
}
