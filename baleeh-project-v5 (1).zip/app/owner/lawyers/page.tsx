import { requireOwner } from '@/lib/owner'
import { createLawyer, toggleLawyer, resetLawyerPassword } from './actions'

const box = { border: '1px solid #d4af3788', borderRadius: 14, padding: 16, marginTop: 10, background: '#14110cb8' }

export default async function Lawyers() {
  const { sb } = await requireOwner()
  const { data: list } = await sb.from('lawyers').select('id,employee_id,profiles(full_name,phone,is_active,username)')
  return (
    <>
      <h1 style={{ color: '#f3d98b' }}>المحامون</h1>
      <form action={createLawyer} style={{ ...box, display: 'grid', gap: 8, maxWidth: 420 }}>
        <b>إضافة محامٍ</b>
        <input name="name" required placeholder="الاسم" />
        <input name="username" required placeholder="اسم المستخدم (إنجليزي)" autoCapitalize="none" />
        <input name="phone" placeholder="الهاتف" />
        <input name="emp" placeholder="Employee ID" />
        <input name="password" type="password" required minLength={10} placeholder="كلمة مرور (10+ أحرف)" />
        <button>إضافة</button>
      </form>
      {(list ?? []).map((l: any) => {
        const p = Array.isArray(l.profiles) ? l.profiles[0] : l.profiles
        return (
          <div key={l.id} style={box}>
            <b>{p?.full_name}</b> (@{p?.username}) — {p?.phone} — {l.employee_id} — {p?.is_active ? '✅ مفعّل' : '⛔ معطّل'}
            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
              <a href={`/owner/lawyers/${l.id}`} style={{ color: '#f3d98b' }}>📂 فتح مساحة المحامي</a>
              <form action={toggleLawyer.bind(null, l.id, !p?.is_active)}><button>{p?.is_active ? 'تعطيل' : 'تفعيل'}</button></form>
              <form action={resetLawyerPassword.bind(null, l.id)}>
                <input name="pw" type="password" minLength={10} required placeholder="كلمة مرور جديدة" /> <button>إعادة تعيين</button>
              </form>
            </div>
          </div>
        )
      })}
    </>
  )
}
