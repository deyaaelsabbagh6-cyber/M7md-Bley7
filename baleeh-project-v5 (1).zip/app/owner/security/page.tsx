import { requireRole } from '@/lib/role'
export default async function Security() {
  const { sb } = await requireRole('owner')
  const [{ data: ev }, { data: au }] = await Promise.all([
    sb.from('security_events').select('*').order('created_at', { ascending: false }).limit(50),
    sb.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(50),
  ])
  const row = { borderBottom: '1px solid #d4af3733', padding: 6, fontSize: 13 }
  return (
    <>
      <h1 style={{ color: '#f3d98b' }}>🔐 مركز الأمان</h1>
      <h2>الأحداث الأمنية</h2>
      {(ev ?? []).map((e) => <div key={e.id} style={row}>{new Date(e.created_at).toLocaleString('ar-EG')} — <b>{e.event}</b> — {e.ip}</div>)}
      <h2>سجل التدقيق</h2>
      {(au ?? []).map((a) => <div key={a.id} style={row}>{new Date(a.created_at).toLocaleString('ar-EG')} — <b>{a.action}</b> — {a.entity} {a.entity_id}</div>)}
    </>
  )
}
