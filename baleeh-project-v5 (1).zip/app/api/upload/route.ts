import { NextResponse } from 'next/server'
import { saveDocument } from '@/lib/docs'
export async function POST(req: Request) {
  try {
    const f = await req.formData()
    const id = await saveDocument(String(f.get('caseId')), f.get('file') as File, f.get('visible') === '1')
    return NextResponse.json({ id })
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 400 }) }
}
